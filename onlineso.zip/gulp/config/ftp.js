export let configFTP = {
  host: '', // адрес ftp сервера
  user: '', // имя пользователя
  password: '', // пароль
  parallel: 5, // кол-во одноверменных потоков
};
